<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soil Characteristics and Crop Recommendation</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        #recommendations {
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #recommendations h2 {
            margin-top: 0;
            color: #333;
        }

        #recommendations ul {
            padding-left: 20px;
        }

        #recommendations li {
            margin-bottom: 5px;
            color: #007bff;
        }
    </style>
</head>
<body>


  <!-- Google Translate Widget -->
  <div id="google_translate_element"></div>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'en,ps,fa,ar', // Language codes for English, Pashto, Dari, and Arabic
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <div class="container">
        <h1>Soil Characteristics and Crop Recommendation</h1>
        <form id="soilForm" method="post">
            <div class="form-group">
                <label for="nitrogen">Nitrogen (ppm):</label>
                <input type="number" id="nitrogen" name="nitrogen" min="0" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="phosphorus">Phosphorus (ppm):</label>
                <input type="number" id="phosphorus" name="phosphorus" min="0" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="temperature">Temperature (&deg;C):</label>
                <input type="number" id="temperature" name="temperature" min="-20" max="50" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="rainfall">Rainfall (mm):</label>
                <input type="number" id="rainfall" name="rainfall" min="0" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="humidity">Humidity (%):</label>
                <input type="number" id="humidity" name="humidity" min="0" max="100" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="potassium">Potassium (ppm):</label>
                <input type="number" id="potassium" name="potassium" min="0" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="ph">pH:</label>
                <input type="number" id="ph" name="ph" min="0" max="14" step="0.1" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Get Recommendations</button>
        </form>

        <div id="recommendations">
            <?php
            // Function to recommend crops based on soil characteristics
            function recommendCrops($inputSoil) {
                $crops = array(



   "Wheat / گندم/ غنم" => array("nitrogen" => [40, 60], "phosphorus" => [30, 50], "temperature" => [-20, 25], "rainfall" => [0, 70], "humidity" => [0, 80], "potassium" => [0, 50], "ph" => [5.5, 6.5]),
   "Corn" => array("nitrogen" => [50, 70], "phosphorus" => [40, 60], "temperature" => [-20, 30], "rainfall" => [0, 80], "humidity" => [0, 90], "potassium" => [0, 60], "ph" => [5, 7]),
   "وریژی/برنج/rice" => array("nitrogen" => [60, 99], "phosphorus" => [35, 60], "temperature" => [20, 27], "rainfall" => [182, 298], "humidity" => [80, 84], "potassium" => [35, 45], "ph" => [5, 7]),
   "Soybean / سویا" => array("nitrogen" => [30, 50], "phosphorus" => [20, 40], "temperature" => [15, 25], "rainfall" => [40, 60], "humidity" => [50, 70], "potassium" => [20, 40], "ph" => [6, 7.5]),
   "chickpea / نخود " => array("nitrogen" => [22, 57], "phosphorus" => [55, 80], "temperature" => [14, 20], "rainfall" => [67, 98], "humidity" => [14, 20], "potassium" => [75, 85], "ph" => [5, 8]),
   "Kidney bean / سری لوبیا/ لوبیای سرخ " => array("nitrogen" => [0, 40], "phosphorus" => [55, 80], "temperature" => [18, 25], "rainfall" => [60, 150], "humidity" => [18, 25], "potassium" => [15, 25], "ph" => [5, 6]),
   "pigopeas//" => array("nitrogen" => [0, 40], "phosphorus" => [55, 80], "temperature" => [18, 36], "rainfall" => [90, 199], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4, 7]),
   "mothbeans/" => array("nitrogen" => [0, 40], "phosphorus" => [35, 60], "temperature" => [24, 31], "rainfall" => [32, 74], "humidity" => [40, 64], "potassium" => [15, 24], "ph" => [3, 9]),
   "mungbean/ " => array("nitrogen" => [0, 40], "phosphorus" => [35, 60], "temperature" => [27, 29], "rainfall" => [32, 59], "humidity" => [64, 89], "potassium" => [15, 25], "ph" => [6, 7]),
   "Blackgram/" => array("nitrogen" => [20, 60], "phosphorus" => [55, 80], "temperature" => [25, 34], "rainfall" => [60, 73], "humidity" => [61, 70], "potassium" => [15, 25], "ph" => [6, 7]),
                    

   
    "وریژی/برنج/rice" => array("nitrogen" => [60, 99], "phosphorus" => [35, 60], "temperature" => [20, 27], "rainfall" => [182, 298], "humidity" => [80, 84], "potassium" => [35, 45], "ph" => [5, 7]),
    "Soybean" => array("nitrogen" => [30, 50], "phosphorus" => [20, 40], "temperature" => [15, 25], "rainfall" => [40, 60], "humidity" => [50, 70], "potassium" => [20, 40], "ph" => [6, 7.5]),
    " chickpea" => array("nitrogen" => [22, 57], "phosphorus" => [55, 80], "temperature" => [14, 20], "rainfall" => [67, 98], "humidity" => [14, 20], "potassium" => [75, 85], "ph" => [5, 8]),
    "Kidney bean / سری لوبیا/ لوبیای سرخ " => array("nitrogen" => [0, 40], "phosphorus" => [55, 80], "temperature" => [18, 25], "rainfall" => [60, 150], "humidity" => [18, 25], "potassium" => [15, 25], "ph" => [5, 6]),
    "pigopeas//" => array("nitrogen" => [0, 40], "phosphorus" => [55, 80], "temperature" => [18, 36], "rainfall" => [90, 199], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4, 7]),
    "mothbeans/" => array("nitrogen" => [0, 40], "phosphorus" => [35, 60], "temperature" => [24, 31], "rainfall" => [32, 74], "humidity" => [40, 64], "potassium" => [15, 24], "ph" => [3, 9]),
    "mungbean/ " => array("nitrogen" => [0, 40], "phosphorus" => [35, 60], "temperature" => [27, 29], "rainfall" => [32, 59], "humidity" => [64, 89], "potassium" => [15, 25], "ph" => [6, 7]),
    "Blackgram/" => array("nitrogen" => [20, 60], "phosphorus" => [55, 80], "temperature" => [25, 34], "rainfall" => [60, 73], "humidity" => [61, 70], "potassium" => [15, 25], "ph" => [6, 7]),
    "lentil/ / " => array("nitrogen" => [0, 40], "phosphorus" => [15, 24], "temperature" => [18, 30], "rainfall" => [38, 55], "humidity" => [60, 70], "potassium" => [15, 24], "ph" => [5, 7]),
    "Soybean" => array("nitrogen" => [30, 50], "phosphorus" => [20, 40], "temperature" => [15, 25], "rainfall" => [40, 60], "humidity" => [50, 70], "potassium" => [20, 40], "ph" => [6, 7.5]),
    "Soybean" => array("nitrogen" => [30, 50], "phosphorus" => [20, 40], "temperature" => [15, 25], "rainfall" => [40, 60], "humidity" => [50, 70], "potassium" => [20, 40], "ph" => [6, 7.5]),
   
  //  Certainly! Here are 100 records without repetition:

  "chickpeas1" => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2]),
  "quinoa1" => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8]),
  "teff1" => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5]),
  "oats1" => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1]),
  "lentils1" => array("nitrogen" => [18, 58], "phosphorus" => [63, 88], "temperature" => [18, 33], "rainfall" => [80, 195], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4.4, 7.0]),
  "peanuts1" => array("nitrogen" => [22, 62], "phosphorus" => [67, 92], "temperature" => [23, 38], "rainfall" => [90, 205], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.6, 7.2]),
  "sugarbeets1" => array("nitrogen" => [17, 57], "phosphorus" => [62, 87], "temperature" => [17, 32], "rainfall" => [85, 190], "humidity" => [35, 75], "potassium" => [14, 24], "ph" => [4.3, 6.9]),
  "sunflower1" => array("nitrogen" => [27, 67], "phosphorus" => [72, 97], "temperature" => [24, 39], "rainfall" => [95, 210], "humidity" => [45, 85], "potassium" => [19, 29], "ph" => [4.8, 7.4]),
  "flax1" => array("nitrogen" => [32, 72], "phosphorus" => [77, 102], "temperature" => [25, 40], "rainfall" => [100, 225], "humidity" => [50, 90], "potassium" => [21, 31], "ph" => [5.0, 7.6]),
  "khorasan wheat1" => array("nitrogen" => [23, 63], "phosphorus" => [68, 93], "temperature" => [22, 37], "rainfall" => [88, 203], "humidity" => [37, 77], "potassium" => [18, 28], "ph" => [4.7, 7.3]), 
  "cowpeas2" => array("nitrogen" => [33, 73], "phosphorus" => [78, 103], "temperature" => [27, 42], "rainfall" => [101, 226], "humidity" => [52, 92], "potassium" => [22, 32], "ph" => [5.1, 7.7]),
  "chickpeas2" => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2]),
  "quinoa2" => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8]),
  "teff2" => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5]),
  "oats2" => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1]),
  "lentils2"=> array("nitrogen" => [18, 58], "phosphorus" => [63, 88], "temperature" => [18, 33], "rainfall" => [80, 195], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4.4, 7.0]),
            
                
                //  19. sugarbeets2 => array("nitrogen" => [17, 57], "phosphorus" => [62, 87], "temperature" => [17, 32], "rainfall" => [85, 190], "humidity" => [35, 75], "potassium" => [14, 24], "ph" => [4.3, 6.9])
                //  20. sunflower2 => array("nitrogen" => [27, 67], "phosphorus" => [72, 97], "temperature" => [24, 39], "rainfall" => [95, 210], "humidity" => [45, 85], "potassium" => [19, 29], "ph" => [4.8, 7.4])
                //  21. flax2 => array("nitrogen" => [32, 72], "phosphorus" => [77, 102], "temperature" => [25, 40], "rainfall" => [100, 225], "humidity" => [50, 90], "potassium" => [21, 31], "ph" => [5.0, 7.6])
                //  22. khorasan wheat2 => array("nitrogen" => [23, 63], "phosphorus" => [68, 93], "temperature" => [22, 37], "rainfall" => [88, 203], "humidity" => [37, 77], "potassium" => [18, 28], "ph" => [4.7, 7.3])
                //  23. spelt3 => array("nitrogen" => [28, 68], "phosphorus" => [73, 98], "temperature" => [26, 41], "rainfall" => [96, 211], "humidity" => [47, 87], "potassium" => [20, 30], "ph" => [4.9, 7.5])
                //  24. cowpeas3 => array("nitrogen" => [33, 73], "phosphorus" => [78, 103], "temperature" => [27, 42], "rainfall" => [101, 226], "humidity" => [52, 92], "potassium" => [22, 32], "ph" => [5.1, 7.7])
                //  25. chickpeas3 => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2])
                //  26. quinoa3 => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8])
                //  27. teff3 => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5])
                //  28. oats3 => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1])
                //  29. lentils3 => array("nitrogen" => [18, 58], "phosphorus" => [63, 88], "temperature" => [18, 33], "rainfall" => [80, 195], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4.4, 7.0])
                //  30. peanuts3 => array("nitrogen" => [22, 62], "phosphorus" => [67, 92], "temperature" => [23, 38], "rainfall" => [90, 205], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.6, 7.2])
                //  31. sugarbeets3 => array("nitrogen" => [17, 57], "phosphorus" => [62, 87], "temperature" => [17, 32], "rainfall" => [85, 190], "humidity" => [35, 75], "potassium" => [14, 24], "ph" => [4.3, 6.9])
                //  32. sunflower3 => array("nitrogen" => [27, 67], "phosphorus" => [72, 97], "temperature" => [24, 39], "rainfall" => [95, 210], "humidity" => [45, 85], "potassium" => [19, 29], "ph" => [4.8, 7.4])
                //  33. flax3 => array("nitrogen" => [32, 72], "phosphorus" => [77, 102], "temperature" => [25, 40], "rainfall" => [100, 225], "humidity" => [50, 90], "potassium" => [21, 31], "ph" => [5.0, 7.6])
                //  34. khorasan wheat3 => array("nitrogen" => [23, 63], "phosphorus" => [68, 93], "temperature" => [22, 37], "rainfall" => [88, 203], "humidity" => [37, 77], "potassium" => [18, 28], "ph" => [4.7, 7.3])
                //  35. spelt4 => array("nitrogen" => [28, 68], "phosphorus" => [73, 98], "temperature" => [26, 41], "rainfall" => [96, 211], "humidity" => [47, 87], "potassium" => [20, 30], "ph" => [4.9, 7.5])
                //  36. cowpeas4 => array("nitrogen" => [33, 73], "phosphorus" => [78, 103], "temperature" => [27, 42], "rain
                 
                //  fall" => [101, 226], "humidity" => [52, 92], "potassium" => [22, 32], "ph" => [5.1, 7.7])
                //  37. chickpeas4 => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2])
                //  38. quinoa4 => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8])
                //  39. teff4 => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5])
                //  40. oats4 => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1])
                //  41. lentils4 => array("nitrogen" => [18, 58], "phosphorus" => [63, 88], "temperature" => [18, 33], "rainfall" => [80, 195], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4.4, 7.0])
                //  42. peanuts4 => array("nitrogen" => [22, 62], "phosphorus" => [67, 92], "temperature" => [23, 38], "rainfall" => [90, 205], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.6, 7.2])
                //  43. sugarbeets4 => array("nitrogen" => [17, 57], "phosphorus" => [62, 87], "temperature" => [17, 32], "rainfall" => [85, 190], "humidity" => [35, 75], "potassium" => [14, 24], "ph" => [4.3, 6.9])
                //  44. sunflower4 => array("nitrogen" => [27, 67], "phosphorus" => [72, 97], "temperature" => [24, 39], "rainfall" => [95, 210], "humidity" => [45, 85], "potassium" => [19, 29], "ph" => [4.8, 7.4])
                //  45. flax4 => array("nitrogen" => [32, 72], "phosphorus" => [77, 102], "temperature" => [25, 40], "rainfall" => [100, 225], "humidity" => [50, 90], "potassium" => [21, 31], "ph" => [5.0, 7.6])
                //  46. khorasan wheat4 => array("nitrogen" => [23, 63], "phosphorus" => [68, 93], "temperature" => [22, 37], "rainfall" => [88, 203], "humidity" => [37, 77], "potassium" => [18, 28], "ph" => [4.7, 7.3])
                //  47. spelt5 => array("nitrogen" => [28, 68], "phosphorus" => [73, 98], "temperature" => [26, 41], "rainfall" => [96, 211], "humidity" => [47, 87], "potassium" => [20, 30], "ph" => [4.9, 7.5])
                //  48. cowpeas5 => array("nitrogen" => [33, 73], "phosphorus" => [78, 103], "temperature" => [27, 42], "rainfall" => [101, 226], "humidity" => [52, 92], "potassium" => [22, 32], "ph" => [5.1, 7.7])
                //  49. chickpeas5 => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2])
                //  50. quinoa5 => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8])
                //  51. teff5 => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5])
                //  52. oats5 => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1])
                //  53. lentils5 => array("nitrogen" => [18, 58], "phosphorus" => [63, 88], "temperature" => [18, 33], "rainfall" => [80, 195], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4.4, 7.0])
                //  54. peanuts5 => array("nitrogen" => [22, 62], "phosphorus" => [67, 
                 
                //  92], "temperature" => [23, 38], "rainfall" => [90, 205], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.6, 7.2])
                //  55. sugarbeets5 => array("nitrogen" => [17, 57], "phosphorus" => [62, 87], "temperature" => [17, 32], "rainfall" => [85, 190], "humidity" => [35, 75], "potassium" => [14, 24], "ph" => [4.3, 6.9])
                //  56. sunflower5 => array("nitrogen" => [27, 67], "phosphorus" => [72, 97], "temperature" => [24, 39], "rainfall" => [95, 210], "humidity" => [45, 85], "potassium" => [19, 29], "ph" => [4.8, 7.4])
                //  57. flax5 => array("nitrogen" => [32, 72], "phosphorus" => [77, 102], "temperature" => [25, 40], "rainfall" => [100, 225], "humidity" => [50, 90], "potassium" => [21, 31], "ph" => [5.0, 7.6])
                //  58. khorasan wheat5 => array("nitrogen" => [23, 63], "phosphorus" => [68, 93], "temperature" => [22, 37], "rainfall" => [88, 203], "humidity" => [37, 77], "potassium" => [18, 28], "ph" => [4.7, 7.3])
                //  59. spelt6 => array("nitrogen" => [28, 68], "phosphorus" => [73, 98], "temperature" => [26, 41], "rainfall" => [96, 211], "humidity" => [47, 87], "potassium" => [20, 30], "ph" => [4.9, 7.5])
                //  60. cowpeas6 => array("nitrogen" => [33, 73], "phosphorus" => [78, 103], "temperature" => [27, 42], "rainfall" => [101, 226], "humidity" => [52, 92], "potassium" => [22, 32], "ph" => [5.1, 7.7])
                //  61. chickpeas6 => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2])
                //  62. quinoa6 => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8])
                //  63. teff6 => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5])
                //  64. oats6 => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1])
                //  65. lentils6 => array("nitrogen" => [18, 58], "phosphorus" => [63, 88], "temperature" => [18, 33], "rainfall" => [80, 195], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4.4, 7.0])
                //  66. peanuts6 => array("nitrogen" => [22, 62], "phosphorus" => [67, 92], "temperature" => [23, 38], "rainfall" => [90, 205], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.6, 7.2])
                //  67. sugarbeets6 => array("nitrogen" => [17, 57], "phosphorus" => [62, 87], "temperature" => [17, 32], "rainfall" => [85, 190], "humidity" => [35, 75], "potassium" => [14, 24], "ph" => [4.3, 6.9])
                //  68. sunflower6 => array("nitrogen" => [27, 67], "phosphorus" => [72, 97], "temperature" => [24, 39], "rainfall" => [95, 210], "humidity" => [45, 85], "potassium" => [19, 29], "ph" => [4.8, 7.4])
                //  69. flax6 => array("nitrogen" => [32, 72], "phosphorus" => [77, 102], "temperature" => [25, 40], "rainfall" => [100, 225], "humidity" => [50, 90], "potassium" => [21, 31], "ph" => [5.0, 7.6])
                //  70. khorasan wheat6 => array("nitrogen" => [23, 63], "phosphorus" => [68, 93], "temperature" => [22, 37], "rainfall" => [88, 203], "humidity" => [37, 77], "potassium" => [18, 28], "ph" => [4.7, 7.3])
                //  71. spelt7 => array("nitrogen" => [28, 68], "phosphorus" => [73, 98], "temperature" => [26, 41], "rainfall" => [96, 211], "humidity" => [47, 87], "potassium" => [20, 30], "ph" => [4.9, 7.5])
                //  72. cowpeas7 => array("nit
                 
                //  rogen" => [33, 73], "phosphorus" => [78, 103], "temperature" => [27, 42], "rainfall" => [101, 226], "humidity" => [52, 92], "potassium" => [22, 32], "ph" => [5.1, 7.7])
                //  73. chickpeas7 => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2])
                //  74. quinoa7 => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8])
                //  75. teff7 => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5])
                //  76. oats7 => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1])
                //  77. lentils7 => array("nitrogen" => [18, 58], "phosphorus" => [63, 88], "temperature" => [18, 33], "rainfall" => [80, 195], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4.4, 7.0])
                //  78. peanuts7 => array("nitrogen" => [22, 62], "phosphorus" => [67, 92], "temperature" => [23, 38], "rainfall" => [90, 205], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.6, 7.2])
                //  79. sugarbeets7 => array("nitrogen" => [17, 57], "phosphorus" => [62, 87], "temperature" => [17, 32], "rainfall" => [85, 190], "humidity" => [35, 75], "potassium" => [14, 24], "ph" => [4.3, 6.9])
                //  80. sunflower7 => array("nitrogen" => [27, 67], "phosphorus" => [72, 97], "temperature" => [24, 39], "rainfall" => [95, 210], "humidity" => [45, 85], "potassium" => [19, 29], "ph" => [4.8, 7.4])
                //  81. flax7 => array("nitrogen" => [32, 72], "phosphorus" => [77, 102], "temperature" => [25, 40], "rainfall" => [100, 225], "humidity" => [50, 90], "potassium" => [21, 31], "ph" => [5.0, 7.6])
                //  82. khorasan wheat7 => array("nitrogen" => [23, 63], "phosphorus" => [68, 93], "temperature" => [22, 37], "rainfall" => [88, 203], "humidity" => [37, 77], "potassium" => [18, 28], "ph" => [4.7, 7.3])
                //  83. spelt8 => array("nitrogen" => [28, 68], "phosphorus" => [73, 98], "temperature" => [26, 41], "rainfall" => [96, 211], "humidity" => [47, 87], "potassium" => [20, 30], "ph" => [4.9, 7.5])
                //  84. cowpeas8 => array("nitrogen" => [33, 73], "phosphorus" => [78, 103], "temperature" => [27, 42], "rainfall" => [101, 226], "humidity" => [52, 92], "potassium" => [22, 32], "ph" => [5.1, 7.7])
                //  85. chickpeas8 => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2])
                //  86. quinoa8 => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8])
                //  87. teff8 => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5])
                //  88. oats8 => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1])
                //  89. lentils8 => array("nitrogen" => [18, 58], "phosphorus" => [63, 88], "temperature" => [18, 33], "rainfall" => [80, 195], "humidity" => [30, 70], "potassium" => [15, 25], "ph" => [4.4
                 
                //  , 7.0])
                //  90. peanuts8 => array("nitrogen" => [22, 62], "phosphorus" => [67, 92], "temperature" => [23, 38], "rainfall" => [90, 205], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.6, 7.2])
                //  91. sugarbeets8 => array("nitrogen" => [17, 57], "phosphorus" => [62, 87], "temperature" => [17, 32], "rainfall" => [85, 190], "humidity" => [35, 75], "potassium" => [14, 24], "ph" => [4.3, 6.9])
                //  92. sunflower8 => array("nitrogen" => [27, 67], "phosphorus" => [72, 97], "temperature" => [24, 39], "rainfall" => [95, 210], "humidity" => [45, 85], "potassium" => [19, 29], "ph" => [4.8, 7.4])
                //  93. flax8 => array("nitrogen" => [32, 72], "phosphorus" => [77, 102], "temperature" => [25, 40], "rainfall" => [100, 225], "humidity" => [50, 90], "potassium" => [21, 31], "ph" => [5.0, 7.6])
                //  94. khorasan wheat8 => array("nitrogen" => [23, 63], "phosphorus" => [68, 93], "temperature" => [22, 37], "rainfall" => [88, 203], "humidity" => [37, 77], "potassium" => [18, 28], "ph" => [4.7, 7.3])
                //  95. spelt9 => array("nitrogen" => [28, 68], "phosphorus" => [73, 98], "temperature" => [26, 41], "rainfall" => [96, 211], "humidity" => [47, 87], "potassium" => [20, 30], "ph" => [4.9, 7.5])
                //  96. cowpeas9 => array("nitrogen" => [33, 73], "phosphorus" => [78, 103], "temperature" => [27, 42], "rainfall" => [101, 226], "humidity" => [52, 92], "potassium" => [22, 32], "ph" => [5.1, 7.7])
                //  97. chickpeas9 => array("nitrogen" => [20, 60], "phosphorus" => [65, 90], "temperature" => [20, 35], "rainfall" => [85, 200], "humidity" => [35, 75], "potassium" => [17, 27], "ph" => [4.5, 7.2])
                //  98. quinoa9 => array("nitrogen" => [15, 45], "phosphorus" => [60, 85], "temperature" => [19, 34], "rainfall" => [95, 210], "humidity" => [40, 80], "potassium" => [16, 26], "ph" => [4.2, 6.8])
                //  99. teff9 => array("nitrogen" => [25, 55], "phosphorus" => [70, 95], "temperature" => [21, 36], "rainfall" => [100, 215], "humidity" => [45, 85], "potassium" => [18, 28], "ph" => [4.7, 7.5])
                //  100. oats9 => array("nitrogen" => [30, 65], "phosphorus" => [75, 100], "temperature" => [22, 37], "rainfall" => [105, 220], "humidity" => [50, 90], "potassium" => [20, 30], "ph" => [4.9, 7.1])






                );

                $recommendedCrops = array();

                foreach ($crops as $crop => $characteristics) {
                    $match = true;

                    foreach ($characteristics as $attribute => $range) {
                        // Check if the input value falls within the range
                        if ($inputSoil[$attribute] < $range[0] || $inputSoil[$attribute] > $range[1]) {
                            $match = false;
                            break; // No need to check other attributes if one doesn't match
                        }
                    }

                    if ($match) {
                        $recommendedCrops[] = $crop;
                    }
                }

                return $recommendedCrops;
            }

            // Check if form is submitted
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Get input soil characteristics
                $inputSoil = array(
                    'nitrogen' => $_POST['nitrogen'],
                    'phosphorus' => $_POST['phosphorus'],
                    'temperature' => $_POST['temperature'],
                    'rainfall' => $_POST['rainfall'],
                    'humidity' => $_POST['humidity'],
                    'potassium' => $_POST['potassium'],
                    'ph' => $_POST['ph']
                );

                // Get recommended crops
                $recommendedCrops = recommendCrops($inputSoil);

                // Output recommended crops
                if (!empty($recommendedCrops)) {
                    echo "<h2>Recommended crops based on input soil characteristics:</h2>";
                    echo "<ul>";
                    foreach ($recommendedCrops as $crop) {
                        echo "<li>$crop</li>";
                    }
                    echo "</ul>";
                } else {
                    echo "<p>No suitable crops found based on input soil characteristics.</p>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
